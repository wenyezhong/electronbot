**资料下载：**

[4.21 拉取原版github压缩包](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRVc3bFRJa2hVVjVDbDhLY2VtZTAwUWNCRWZPQlZEbFFUN0pZdjRZYnFPZHVYdz9lPXZFdUQ1NA.zip)						

| [立创下单小助手](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRVdqb1YwWTRCZHBIbmV0RzRuRXN5V1FCWTV5UERxSDN2d1QtM0FCWHFmVFNzdz9lPWpHYkt3UA.zip) | [stm32cubeMx](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRVNDVFFyTXZ4NFpQdDF4SUVjc1BaSklCNVV4dFZmM2hiVXIzWEdHZkJmTUhjQT9lPXFqenZ6Ng.zip) | 2021.3.1 [clion](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRWRySGJ5NHB4WXBLcHQ5UFR0ZnJXSE1CbUFfcnBxWGtCS0lCb3pmN3FFMVJHQT9lPU9jZ1V6MA.zip) |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| [AD](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRVpLakJ0aVlsNUJQclZ1N09yZFk4X3NCMVhGeEstdUh5MmtJZGdtczFJRkRNZz9lPUNsQTF4SA.zip) | [opencv 348](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRVhhLTRxSkIxdzlLdlpvd0ZKajNZNklCbkJ1bjg4RGdLUHp0YWpPRkpqQnlzQT9lPTBlakFqbA..exe) | [StlinkUtility](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRVNVc2czZXdrckZNcDBva1dwNkZXcUlCamhmZjV4cHZsVzEtVEJQc1JoV29LQT9lPW1wZGJmUg.zip) |
| [stlink驱动](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRVJ6a0ZzUno0SDVJcEdBTTdCdjUxY1FCSXdGcGhiN1kxR0g0cWpKc19EWmhXdz9lPUl4dWdlVA.zip) | [cp2102驱动 ](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRWVkU2xyZzM5TlZNajFoNDF6Um9YandCdUpYc1I4WGlBNTZwSUZRUUVvM19mQT9lPXVDcDdUdg.zip) | [gcc](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRWR1V3pJWW9haVZDdEF1a3gwVERXY0FCaWhnV3YtREZ1M1JodkdreXRqckZMZz9lPTk4dllENw.zip) |
| [MinGW](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRVEzQ2d2bjhrZ1JQcFJtWGVRSGJEWElCNEJ1dnRxVHl6eElyMkoxT1VsdXRrdz9lPXRjbzVpdA.zip) | [openocd](https://link.jscdn.cn/sharepoint/aHR0cHM6Ly90eHA2NjYtbXkuc2hhcmVwb2ludC5jb20vOnU6L2cvcGVyc29uYWwvdHhwX3R4cDY2Nl9vbm1pY3Jvc29mdF9jb20vRVctazg0LUcwZ05NdDk3SGF0TFl3MXdCZ0VPY29QLWphLUhxTDd6THlHLUY1QT9lPTdJa0ROYg.zip) |                                                              |

无法下载或下载速度慢可以用百度网盘

链接: https://pan.baidu.com/s/1p0newnkKFVqm6W-avRse6w?pwd=cxn6 提取码: cxn6 复制这段内容后打开百度网盘手机App，操作更方便哦

QQ群：147597938

ElectronBot_Unity压缩包是补充了dll的unity上位机 来自群文件 感谢群友的分享！

| 值                                                           | 封装                       | 数量 | 分类     |                         备注                          |
| ------------------------------------------------------------ | -------------------------- | ---- | -------- | :---------------------------------------------------: |
| 2.2nF                                                        | CAP_0402                   | 1    | 电容电阻 |              阻容立创商城或者优信电子买               |
| 10nF                                                         | CAP_0402                   | 10   |          |                                                       |
| 0.1uF                                                        | CAP_0402                   | 31   |          |                                                       |
| 10uF                                                         | CAP_0402                   | 17   |          |                                                       |
| 0R                                                           | RES_0402                   | 3    |          |                                                       |
| 4.7R                                                         | RES_0402                   | 1    |          |                                                       |
| 10R                                                          | RES_0402                   | 1    |          |                                                       |
| 120R                                                         | RES_0402                   | 6    |          |                                                       |
| 200R                                                         | RES_0402                   | 1    |          |                                                       |
| 5.1K                                                         | RES_0402                   | 2    |          |                                                       |
| 10K                                                          | RES_0402                   | 13   |          |                                                       |
| 12K                                                          | RES_0402                   | 1    |          |                                                       |
| 47K                                                          | RES_0402                   | 5    |          |                                                       |
| 100K                                                         | RES_0402                   | 1    |          |                                                       |
| 1M                                                           | RES_0402                   | 1    |          |                                                       |
| [24MHz](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=569633363622&_u=b20q7cgb7b7b) | 晶振-3P                    | 1    | 晶振     |                                                       |
| [8MHz](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=569633363622&_u=b20q7cgb7b7b) | 晶振-3P                    | 1    |          |                                                       |
| [CP2102](https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-21223910208.11.38616a4bJvtoO5&id=522575454240) | QFN-28                     | 1    | 芯片     |                                                       |
| [LP2992 3V3](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.29ee2e8dahZw7u&id=559236610497&_u=s20q7cgb15f7) | SOT23-5                    | 8    |          | 已修改为XC6210B332MR 3.3V/0.7A 可以替换2992，电流增大 |
| [STM32F405RGT6](https://item.taobao.com/item.htm?spm=2013.1.w4018-21223910180.7.37634c481b1TNL&scm=1007.11837.279802.0&id=522577756409&pvid=aa1f18aa-1d2d-4c48-aca4-2510d8bd8b76) | LQFP-64_N                  | 1    |          |                                                       |
| [STM32F030F6](https://item.taobao.com/item.htm?spm=a1z0d.6639537.1997196601.14.6ce87484rl1x1l&id=522554611977) | TSSOP-20                   | 6    |          |                                                       |
| [USB3300-EZK-TR](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=615706097828&_u=b20q7cgb7b9f) | QFN-32                     | 1    |          |                                                       |
| [HS8836A](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.5cf62e8dtZRRxc&id=595763295882&_u=p20q7cgb9d59) | SO-16N                     | 1    |          |                                                       |
| [MPU6050](https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-21223910208.13.12246a4bkkMiAU&id=522575310310) | QFN-24                     | 1    |          |                       可以不买                        |
| [PAJ7620U2](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=571178228286&_u=b20q7cgb3b28) | PAJ7620U2                  | 1    |          |                                                       |
| [FM116B](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=618979113359&_u=b20q7cgb4a9d) | SOT23-6                    | 6    |          |                                                       |
| [AO3400A](https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-21223910208.9.43706a4bLb8vCV&id=522574089119) | SOT23-3                    | 1    |          |                                                       |
| [TL431IDBZT](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.67002e8dJ6XlJx&id=554339815306&_u=b20q7cgbc675) | SOT23-3                    | 6    |          |                                                       |
| [Type-C](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.62442e8demH03x&id=573090887123&_u=g20q7cgb5a83) |                            | 1    | 连接件   |                                                       |
| [FFC_0.5_8](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.62442e8dmareSl&id=552629356951&_u=g20q7cgb4b1f) | FFC_0.5_8                  | 4    |          |                                                       |
| [SH1.0-4P](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.62442e8demH03x&id=565715285795&_u=g20q7cgbab7d) | SH1.0-4P                   | 10   |          |            3 4 p都多买点5p是DK板的可以不买            |
| TF-Socket                                                    | TF-Card-Amphenol with TF   | 1    |          |                       可以不买                        |
| [LCD-240x240-ROUND](https://item.taobao.com/item.htm?spm=a210c.1.0.0.79791debq2j2F8&id=666438287702&qq-pf-to=pcqq.c2c) | GC9A01                     | 1    |          |                                                       |
| [表盘](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=624702562166&_u=b20q7cgb2244) | 31.5mm                     | 1    |          |                                                       |
| [摄像头](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=567717780577&_u=b20q7cgb6b84) | usb摄像头                  | 1    |          |                                                       |
| [FFC排线](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.5cf62e8dtZRRxc&id=549590794021&_u=p20q7cgb7a40) | 0.5*8                      | 10   |          |                 同向反向都买点，10cm                  |
| [4.3g舵机](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=601889539677&_u=b20q7cgb34d4) |                            | 5    |          |                                                       |
| [9g舵机](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.5cf62e8dtZRRxc&id=577455964879&_u=p20q7cgb27e6) |                            | 1    |          |                                                       |
| [SH1.0 4p线](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.62442e8demH03x&id=565360096163&_u=g20q7cgb107d) |                            | 6    |          |            3 4 p都买点 5p是DK板的可以不买             |
| [推杆](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=597058278501&_u=b20q7cgb396b) | M2*25                      | 2    |          |                                                       |
| [轴承](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=550670695721&_u=b20q7cgbace2)      [轴承](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=626925470285&_u=b20q7cgbb95a) | 肩膀6x10x3mm 腰部25x32x4mm |      |          |                   内径25外径32高度4                   |
| [螺丝](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.1f3c2e8df9Af9i&id=571154046536&_u=b20q7cgb74bb) | M2                         | 若干 |          |    螺丝挑几个M2*4,5,6的买点就行，我图方便买了一盒     |
| [m1*10](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.98452e8dyw0XaE&id=591244120254&_u=m20q7cgb4fc2) | 舵机拆后壳后固定           | 12   |          |                                                       |
