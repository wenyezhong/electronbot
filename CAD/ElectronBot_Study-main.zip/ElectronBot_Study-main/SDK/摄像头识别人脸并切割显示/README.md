在lowlevel中替换sample.cpp

把NoFace.jpg放入工程根目录

vs环境请参考视频https://www.bilibili.com/video/BV1zq4y1a7r4?share_source=copy_web

