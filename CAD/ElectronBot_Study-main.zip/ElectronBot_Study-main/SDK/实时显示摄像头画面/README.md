在lowlevel中替换sample.cpp

vs环境请参考视频https://www.bilibili.com/video/BV1zq4y1a7r4?share_source=copy_web